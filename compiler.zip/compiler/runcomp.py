import os
import sys
with open("path.txt") as f:
    kospath = f.readline().rstrip()+'\killos.py'
os.system('del path.txt')
os.system(f'pyinstaller --noconfirm --onedir --console  "{kospath}"')
sys.exit()